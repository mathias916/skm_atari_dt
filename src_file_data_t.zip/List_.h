//#include "datatype.h"



#include <stddef.h>





class List_
{
	
	
public:

	typedef struct Node_
	{
		DataT_ data_;
		DataT_Key key_;
		
		Node_ *next;
		Node_ *prev;
	}Node_;



private:	


Node_ *	head_;
Node_ *	tail_;
Node_ *	Itorator_;
Node_ *	list_;


long size_;

public:
////////////////////////////////////////////////////////////////////////////////////////////////////
//construct/destruct//
List_();
~List_();
////////////////////////////////////////////////////////////////////////////////////////////////////
//stack function//
int	Push(DataT_ );
DataT_ 	Pop();
DataT_	Top();
////////////////////////////////////////////////////////////////////////////////////////////////////
//list function//
int	Insert(DataT_);
int	Insert(DataT_, DataT_Key);

int	Delete(DataT_Key);
////////////////////////////////////////////////////////////////////////////////////////////////////
//queue function//
int	enQueue(DataT_ );
DataT_ 	deQueue();
////////////////////////////////////////////////////////////////////////////////////////////////////
//general function
int	clear_list();
int	HasNext();
int	HasPrev();
Node_ * iBegin(); 	//return itorator_ = head
Node_ * iEnd();	//return itorator_ = tail
Node_ *	gHead();
Node_ *	gTail();
Node_ *	gItorator();
Node_ *	gHSub(unsigned long);
Node_ *	gTSub(unsigned long);
Node_ *	gNext();
Node_ *	gPrev();
Node_ * NewNode();
long 	Size();
void    LinkListNode(Node_ *);		//link current itorator node
void    LinkListNode(Node_ *,Node_*); //link any node I dont care
DataT_	ShowData(Node_ *);
////////////////////////////////////////////////////////////////////////////////////////////////////
};//List_ class


////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////

//construct/destruct//
List_::List_()
{
	list_ = NULL;
	head_= NULL;
	tail_= NULL;
	Itorator_= NULL;	
	size_ = 0;
}

List_::~List_()
{
	if(list_ != NULL)
	clear_list();
}


void  List_::LinkListNode(Node_ *List_In)
{	
	if(List_In != NULL){

		if(list_ == NULL){		
		list_ = List_In; 
		list_->next = NULL;
		list_->prev = NULL;
		head_ = list_;
		tail_ = list_;
		Itorator_ = list_;
		}
		else
		{
		List_In->prev = Itorator_->prev;
		List_In->next = Itorator_->next;
		delete Itorator_;
		Itorator_ = List_In;
		}
		
	}
}


void  List_::LinkListNode(Node_ *List_In0, Node_ *List_In1)
{	
	if(List_In0 != NULL && List_In1){

	
	List_In0 = List_In1;
	
		
	}
}

long	List_::Size()
{
return size_;
}

//stack function//
int	List_::Push(DataT_ input_)
{
	if(this->Size() == 0){  
	//start new list
	//set list addressing
	if(list_ == NULL) list_ = new Node_;
	list_->next  = NULL;
	list_->prev  = NULL;
	list_->data_ = input_;
	head_ = list_;
	tail_ = list_;
	Itorator_ = list_;
	return ++size_;	
	//else push onto list STACK
	}else{
	head_->prev = new Node_;
	Itorator_ = head_;
	head_ = head_->prev;
	head_->next = Itorator_;
	head_->prev = NULL;
	head_->data_ = input_;
	return ++size_;
	}	
	 
}


DataT_ 	List_::Pop()
{
	//pop head ,delete, fix addressing, return dataT
if(head_->next != NULL)
{
	Itorator_ = head_;
	head_ = head_->next;
	DataT_ temp_ = Itorator_->data_;
	delete Itorator_;
	head_->prev = NULL;
	--size_;
	return temp_;
}
else
{
	if(list_==NULL){
	size_ = 0;
	DataT_ * temp = NULL;
	 return *temp;}

	 Itorator_ = head_;
	DataT_ temp_ = head_->data_;
	delete  Itorator_;
	list_ = NULL;
 	--size_ ;
	return temp_;
}

}


DataT_ 	List_::Top()
{
	if(head_ != NULL)
	Itorator_ = head_;
	else{
	DataT_ * temp = NULL;
	 return *temp; }
	return Itorator_->data_;

}


int	List_::Insert(DataT_ data_in, DataT_Key key_in)
{


	if(list_ == NULL)
	{
	//start new list
	list_ = new Node_;
	list_->next = NULL;
	list_->prev = NULL;	
	//set list addressing
	head_ = list_;
	tail_ = list_;
	Itorator_ = list_;
	list_->data_ = data_in;
	list_->key_ = key_in;
	return ++size_;
	}else{
	//add to existing list

	Itorator_ = head_;
	Node_ *	new_node;
	new_node = new Node_;
	new_node->data_ = data_in;
	new_node->key_ = key_in;

	
	while(key_in <= Itorator_->key_ && Itorator_->next != NULL) Itorator_ = Itorator_->next;


	if(Itorator_->next == NULL && key_in <= Itorator_->key_)
	{
	Itorator_->next = new_node;
	tail_ = Itorator_->next;
	tail_->prev = Itorator_;
	tail_->next = NULL;
	return ++size_;
	}

	if(Itorator_ == head_)
	{
	new_node->next = head_;
	new_node->prev = NULL;
	head_->prev = new_node;
	head_ = new_node;
	return ++size_;
	}

	if(Itorator_ != head_)
	{	
	new_node->next = Itorator_;
	new_node->prev = Itorator_->prev;
	Itorator_->prev->next = new_node;
	Itorator_->prev = new_node;
	return ++size_;
	}
	
	
	
	
	
	}//else




}


List_::Node_ * List_::NewNode()
{
Node_ * Rtn_node;
Rtn_node = new Node_;
Rtn_node->next =NULL;
Rtn_node->prev =NULL;
return Rtn_node;
}


/*
//list function//
int	List_::Insert(DataT_ data_in)
{
	if(list_ == NULL)
	{
	//start new list
	list_ = new Node_;
	list_->next = NULL;
	list_->prev = NULL;	
	//set list addressing
	head_ = list_;
	tail_ = list_;
	Itorator_ = list_;
	list_->data_ = data_in;
	return ++size_;
	}else{
	//add to existing list

	Itorator_ = head_;
	Node_ *	new_node;
	new_node = new Node_;
	new_node->data_ = data_in;

	
	while(data_in <= Itorator_->data_ && Itorator_->next != NULL) Itorator_ = Itorator_->next;


	if(Itorator_->next == NULL && data_in <= Itorator_->data_)
	{
	Itorator_->next = new_node;
	tail_ = Itorator_->next;
	tail_->prev = Itorator_;
	tail_->next = NULL;
	return ++size_;
	}

	if(Itorator_ == head_)
	{
	new_node->next = head_;
	new_node->prev = NULL;
	head_->prev = new_node;
	head_ = new_node;
	return ++size_;
	}

	if(Itorator_ != head_)
	{	
	new_node->next = Itorator_;
	new_node->prev = Itorator_->prev;
	Itorator_->prev->next = new_node;
	Itorator_->prev = new_node;
	return ++size_;
	}
	
	
	
	
	
	}//else


}
*/

int	List_::Delete(DataT_Key)
{

return 0;

}

//queue function//
int	List_::enQueue(DataT_ input_)
{
	if(size_ == 0){
	
	//set list addressing 
	list_ = new Node_;
	list_->next = NULL;
	list_->prev = NULL;
	head_ = list_;
	tail_ = list_;
	Itorator_ = list_;
	list_->data_ = input_;
	return ++size_;
	}else{
	Itorator_ = head_;
	Itorator_->prev = new Node_;
	Itorator_ = Itorator_->prev;
	Itorator_->next = head_;
	Itorator_->prev = NULL;
	head_ = Itorator_;
	head_->data_ = input_;	
	return ++size_;	
	}
	
	


}

DataT_ 	List_::deQueue()
{

Node_ * Tmp;



if(list_->prev != NULL)
{
	Itorator_ = list_;
	DataT_ temp_ = Itorator_->data_;
	list_ = list_->prev;
	delete Itorator_;
	list_->next = NULL;
	tail_ = list_;
	--size_;
	return temp_;
}else{
	 
	 
	DataT_ temp_ = list_->data_;	
	delete list_;	 
	head_ = NULL;
	tail_ = NULL;
	Itorator_ = NULL;
	 size_ = 0;
	return temp_;
}

}



List_::Node_* 	List_::gHead()
{
return head_;
}

List_::Node_* List_::gTail()
{
return tail_;
}

List_::Node_* List_::gItorator()
{
return Itorator_;
}

//head sub
List_::Node_* List_::gHSub(unsigned long Lin)
{
if(Lin < 0 ) return NULL;

int l = 0;
Itorator_ = gHead();
while(l < Lin){ ++l;
if(Itorator_->next != NULL) Itorator_ = Itorator_->next; else return Itorator_; 
}
return Itorator_;
}

//tail sub
List_::Node_* List_::gTSub(unsigned long Lin)
{
if(Lin < 0 ) return NULL;

int l = 0;
Itorator_ = gTail();
while(l < Lin){ ++l;
if(Itorator_->prev != NULL) Itorator_ = Itorator_->prev; else return Itorator_; 
}
return Itorator_;
}

//general function
int List_::clear_list()
{
if(size_ == 0) return 0; //had no list


Node_ * Tmp;
 

Tmp = head_; 
while(Tmp->next != NULL)
{
--size_;
Itorator_ = Tmp;
Tmp = Tmp->next; delete Itorator_;
Tmp->prev = NULL;
}
 

size_ = 0;

return size_;//size would be zero
}


List_::Node_ * List_::iBegin()
{
return Itorator_ = head_;
}

List_::Node_ * List_::iEnd()
{
return Itorator_ = tail_;
}

List_::Node_ *	List_::gNext()
{
return Itorator_ =  (Itorator_->next == NULL ? NULL : Itorator_->next );
}
List_::Node_ *	List_::gPrev()
{
return (Itorator_ =  (Itorator_->prev == NULL ? NULL : Itorator_->prev ));
}

DataT_	List_::ShowData(List_::Node_ *in_pointer)
{
return in_pointer->data_;
}

int	List_::HasNext()
{
return Itorator_->next == NULL ? 0: 1; 
}
int	List_::HasPrev()
{
return Itorator_->prev == NULL ? 0: 1; 
}