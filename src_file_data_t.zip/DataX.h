
#define _DATA_X_

/*
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
INPUT1: namespace <name>   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
INPUT2: typedef <type> data_t 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Container Class
Dynamic data handle


PROGRAMMER:MJO 2015'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

 

class DataX
{



//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//data types and members

private:

/* BASETYPES */
typedef unsigned long ULONG;
typedef ULONG *PULONG;
typedef unsigned short USHORT;
typedef USHORT *PUSHORT;
typedef unsigned char UCHAR;
typedef UCHAR *PUCHAR;
typedef char *PSZ;
 

data_t	* Dx;
ULONG size;

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

public:

DataX();
DataX(ULONG );
~DataX();

data_t *  	NewDx(ULONG size_);
data_t * 	GetDx();
ULONG		Size();
void		ClearDx();


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//INLINE OPERATORS


inline data_t & operator [] ( ULONG size_t )
{
	return   (this->Dx[size_t]);
}

inline void operator  =  ( char * Right)  //FOR CHARACTER STRINGS ONLY
{
	strcpy( (char*) this->Dx , Right);
	return    ;
}

inline int operator  ==  ( char * Right)  //FOR CHARACTER STRINGS ONLY
{
	return strcmp( (char*) this->Dx , Right);
	
}
 


};

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/


DataX::~DataX()
{
	ClearDx();
}

DataX::DataX(ULONG size_)
{
size = 0;
Dx=NULL;
	NewDx(size_);
}

DataX::DataX()
{
	size = 0;
	Dx=NULL;
}


ULONG DataX::Size()
{
	return this->size;
}

data_t * DataX::GetDx()
{
return this->Dx;
}



void DataX::ClearDx()
{
if(this->Dx != NULL && sizeof(this->Dx) > sizeof(data_t))  delete [] Dx;	
else if(this->Dx != NULL && sizeof(this->Dx) == sizeof(data_t)) delete Dx;
size = 0; this->Dx = NULL;
return;
}


 
data_t *  DataX::NewDx(ULONG size_)
{
if(this->Dx != NULL) ClearDx();
	this->Dx = new data_t [size_]; 
			if(this->Dx == NULL) 
					return NULL;
					else{	this->size = size_;
						 return this->Dx;
					    }

}



/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/