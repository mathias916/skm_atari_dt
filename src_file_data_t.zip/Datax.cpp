

#include <sfx.h>
#include <winfx.h>

 
 
 
Ns(Dxf) { 
Type(float,data_t)
#include <datax.h>
}

Ns(DxCs) { 
Type(char,data_t)
#include <datax.h>
}
  	
Ts(Data_s){
			ULONG size;
			Dxf::DataX F3;
	}Data_s;


void main()
{

Dxf::DataX	fBuffer(55);

//CBuffer = "EveryGoodClassHandlesOperators";

for(ULONG x=0; x< fBuffer.Size() ;++x)
printf("\n%-3d %f",x+1, fBuffer[x] );




getch();

}