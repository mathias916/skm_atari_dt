#include <3dobjclass.h>
#include "skm.cpp"




Load_VTX_2_AN8(Obj3d * In_, char* FName)
{
typedef unsigned long CType;

In_->LoadVtxFile(FName);
In_->InitVtx();

/////////////init Global SKM DATA HERE (COPY)//////////////////

{//scope

//vertex data/////////////////////////////////////////////////////////////////////
// float ***Object[3]; //[vertex, texel coords, normals][face][point][x,y,z]
//

XYZ_ tXYZ_;
XYZi_ tXYZi_;
Texture_ tTexture_;



CType i = 0;
CType ccount = 0;

for(CType y = 0; y<In_->Facesets;++y)
{

for(CType f = 0; f< In_->Model_[y].nFaces;++f){

if(f==0){
printf("\nnFaces:%d", In_->Model_[y].nFaces);
printf("\nnPoints:%d\n", In_->Model_[y].nPoints);
system("pause");}

for(CType p = 0; p< 3;++p){

ccount++;
////////points //vertex //////////////////////

tXYZ_.x = In_->Model_[y].Object[0][f][p][0];
tXYZ_.y = In_->Model_[y].Object[0][f][p][1];
tXYZ_.z = In_->Model_[y].Object[0][f][p][2];
tXYZ_.w = 0;

GData.Vertdata_.enQueue(tXYZ_);

//////////////textures //////////////////////

tTexture_.x = In_->Model_[y].Object[1][f][p][0];
tTexture_.y = In_->Model_[y].Object[1][f][p][1];
tTexture_.z = In_->Model_[y].Object[1][f][p][2];
tTexture_.u = 0;

GData.TexelCoords_.enQueue(tTexture_);


/////////////Normals //////////////////////

tXYZ_.x = In_->Model_[y].Object[2][f][p][0];
tXYZ_.y = In_->Model_[y].Object[2][f][p][1];
tXYZ_.z = In_->Model_[y].Object[2][f][p][2];
tXYZ_.w = 0;

GData.Normdata_.enQueue(tXYZ_);


}}//for//f//p//


////////face index//////////////
 

  


}//for y



for(; i< ccount ; ++i)
{
tXYZi_.i = i;
GData.Facedata_.enQueue(tXYZi_);
}


}//scope

#define PAUSE1 system("pause");

printf("\n...vtx file loaded...\n"); PAUSE1

//////////////custom loader//////////////////////


int tempf[2];
fstream dfile;
fstream ofile;

char Buff[255];
string fname1;
fname1.assign(FName);
fname1.append(".an8");
ofile.open((char*)fname1.data(),  ios::in | ios::out | ios::trunc | ios::ate );
ofile.seekg(0);




XYZ_ tempxyz;
int count;


///Write initializes data to opened an8 file
//.AN8 file format heading inits 



ofile<<"header {\n  version { \"0.95\" }\n  build { \"2007.04.02\" }\n}\nenvironment {\n  grid { 0 5 10 50 }\n";
ofile<<"  framerate { 24 }\n}\nobject { \"Convert_1.0\"\n  mesh {\n    name { \"mesh01\" }\n    base {\n";
ofile<<"      origin { (0 0 0) }\n    }\n    material { \" -- default --\" }\n    smoothangle { 45 }\n";
ofile<<"    /* "<<GData.HData[2].count<<" points, "<<GData.HData[3].count<<" faces, "<<GData.HData[2].count<<" uvCoords */\n";
ofile<<"    materiallist {\n      materialname { \" -- default --\" }\n    }";


ofile<<"\n    points {";

GData.Vertdata_.iEnd(); count = 0;
while(GData.Vertdata_.HasPrev()){  ++count; if(count%3==1) ofile<<endl<<"      ";
ofile<<"("
<<GData.Vertdata_.ShowData(GData.Vertdata_.gItorator()).x<<" "
<<GData.Vertdata_.ShowData(GData.Vertdata_.gItorator()).y<<" "
<<GData.Vertdata_.ShowData(GData.Vertdata_.gItorator()).z
<<") ";

GData.Vertdata_.gPrev();
//if(count % 50 == 0) 
//system("pause"); 
}

ofile<<"\n    }";
ofile<<"\n    texcoords {";

GData.TexelCoords_.iEnd(); count = 0;
while(GData.TexelCoords_.HasPrev()){ ++count; if(count%3==1) ofile<<"\n      ";
ofile<<"("
<<GData.TexelCoords_.ShowData(GData.TexelCoords_.gItorator()).x<<" "
<<GData.TexelCoords_.ShowData(GData.TexelCoords_.gItorator()).y<<")"
<<" ";
GData.TexelCoords_.gPrev();   
}


ofile<<"\n    }";
ofile<<"\n    faces {";

dfile.clear();
GData.Facedata_.iEnd(); count = 0;
while(GData.Facedata_.HasPrev()){ ++count; if(count%3 == 1 && count != 1) ofile<<")\n      3 4 0 -1 ( "; if(count == 1) ofile<<"\n      3 4 0 -1 ( ";
ofile<<"("<<GData.Facedata_.ShowData(GData.Facedata_.gItorator()).i<<" "<<GData.Facedata_.ShowData(GData.Facedata_.gItorator()).i<<") ";
GData.Facedata_.gPrev();
}
ofile<<")\n    }\n  }\n}";



printf("\ncount: %d\n",count);
//system("pause");

int L; GData.Facedata_.iEnd();
while(GData.Facedata_.HasPrev())
{

L=0; GData.Vertdata_.iEnd(); GData.Normdata_.iEnd(); GData.TexelCoords_.iEnd();
while(GData.Vertdata_.HasPrev()  && (L < GData.Facedata_.ShowData(GData.Facedata_.gItorator()).i) ){++L; 
GData.Vertdata_.gPrev(); GData.Normdata_.gPrev(); GData.TexelCoords_.gPrev();}

ModelData_ TempModel;
TempModel.Vect = GData.Vertdata_.ShowData(GData.Vertdata_.gItorator());
TempModel.Norm = GData.Normdata_.ShowData(GData.Normdata_.gItorator());
TempModel.Texel = GData.TexelCoords_.ShowData(GData.TexelCoords_.gItorator());

GData.Model_.enQueue(TempModel);
GData.Facedata_.gPrev();
}

ofile.close();
dfile.close();
return 1;



}




int main(int argc, char* argv[])
{
if(argc > 1)
{

Obj3d STUB;
Load_VTX_2_AN8(&STUB,argv[1]);
printf("\n...task complete...\n");	PAUSE1
return 0;
}
else{
printf("\nInput VTX File needed\n"); system("pause");
return 1;}

}