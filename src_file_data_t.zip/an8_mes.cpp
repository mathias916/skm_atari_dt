









#include "skm.cpp"

SKMData AN8_Model;


ParseAN8(char *fname)
{


fstream an8f;
SKMHeader_T HData[4];

an8f.open(fname, ios::in | ios::out | ios::ate);
an8f.seekg(0,ios::beg);

char buffer[256];
while(strcmp(buffer,"points") != 0 && !an8f.fail()) an8f>>buffer;
an8f.getline(buffer, 80, '\n');

XYZ_ temp;

long count = 0;
do
{
if(count == 0) an8f>>buffer[0];

an8f>>temp.x>>temp.y>>temp.z>>buffer[1];
AN8_Model.Vertdata_.enQueue(temp);
an8f>>buffer[0];
printf("\nx:%f y:%f z:%f", temp.x, temp.y, temp.z);
++count;
}while(buffer[0] == '(');

HData[2].count = count;
printf("\nVector count:%i\n",count);
system("pause");


while(strcmp(buffer,"normals") != 0 && !an8f.fail()) an8f>>buffer;
an8f.getline(buffer, 80, '\n');

XYZ_ normalize_ = {0,0,0,0};

count = 0;
do
{
if(count == 0) an8f>>buffer[0];

an8f>>temp.x>>temp.y>>temp.z>>buffer[1];

normalize_.x += temp.x;
normalize_.y += temp.y;
normalize_.z += temp.z;

AN8_Model.Normdata_.enQueue(temp);
an8f>>buffer[0];
++count;
printf("\nx:%f y:%f z:%f", temp.x, temp.y, temp.z);
}while(buffer[0] == '(');

normalize_.x /= count;
normalize_.y /= count;
normalize_.z /= count;

printf("\navge: x:%f y:%f  z:%f ",normalize_.x,normalize_.y,normalize_.z);


/*
count = 0;
AN8_Model.Normdata_.iEnd();
while(AN8_Model.Normdata_.HasPrev()){
if(count != 0)
AN8_Model.Normdata_.gPrev();

AN8_Model.Normdata_.gItorator()->data_.x /= normalize_.x;
AN8_Model.Normdata_.gItorator()->data_.y /= normalize_.y;
AN8_Model.Normdata_.gItorator()->data_.z /= normalize_.z;
++count;
}
*/

printf("\nNormal count:%i\n",count);
system("pause");

while(strcmp(buffer,"texcoords") != 0 && !an8f.fail()) an8f>>buffer;
an8f.getline(buffer, 80, '\n');

Normal_ tmptexel;

count = 0;
do
{
if(count == 0) an8f>>buffer[0];

an8f>>tmptexel.x>>tmptexel.y>>buffer[1];
AN8_Model.TexelCoords_.enQueue(tmptexel);
an8f>>buffer[0];
++count;
printf("\nu:%f v:%f", tmptexel.x, tmptexel.y);
}while(buffer[0] == '(');

printf("\ntexel Coord count:%i\n",count);
system("pause");


while(strcmp(buffer,"faces") != 0 && !an8f.fail()) an8f>>buffer;
an8f.getline(buffer, 80, '\n');


XYZi_ tmpface;
XYZi_ tmpnormi;
long templ;
vect3i::List_ tmpnormal;


count = 0;
do
{

an8f>>templ;
if(templ != 3) break;

an8f>>templ;an8f>>templ;an8f>>templ;


an8f>>buffer[0];

for(int x = 0; x<3;++x){
an8f>>buffer[0]>>tmpface.i>>tmpnormi.i>>templ>>buffer[1];
AN8_Model.Facedata_.enQueue(tmpface);
tmpnormal.enQueue(tmpnormi);
printf("\nfi:%i ni:%i", tmpface.i, tmpnormi.i);
}



an8f>>buffer[0];
++count;
}while(buffer[0] == ')');

HData[3].count = count;

an8f.close();
printf("\nindex counts:%i",count);
printf("\nAn8 parse done! file closed.\n");
system("pause");

///////////Sort // init data/////////////////
//create mes file
fstream omesf;
string fnamestr(fname);
fnamestr.append(".mes");
omesf.open((char*)fnamestr.data(), ios::in | ios::out | ios::ate | ios::trunc | ios::binary);
omesf.seekp(0,ios::beg); 





//write head data//
HData[0].count = 0;
HData[1].count = 0;

HData[0].offset = 0;
HData[1].offset = 0;
HData[2].offset = 0;
HData[3].offset = 0;

omesf.write(reinterpret_cast<char*>(&HData), 32);


//write an8 mes file data loop//
AN8_Model.Vertdata_.iEnd();
AN8_Model.TexelCoords_.iEnd();
//AN8_Model.Normdata_.iEnd();
tmpnormal.iEnd();


printf("\nWriting File .mes");

float dummy = 0; int Le = 0;
int L;


do{


if(Le != 0)
{
AN8_Model.Vertdata_.gPrev();AN8_Model.TexelCoords_.gPrev(); //AN8_Model.Normdata_.gPrev();
tmpnormal.gPrev();
}


omesf.write(reinterpret_cast<char*>(&AN8_Model.Vertdata_.ShowData(AN8_Model.Vertdata_.gItorator())), 4*4);

//sort//
 
L = 0;AN8_Model.Normdata_.iEnd();
while(L< tmpnormal.ShowData(tmpnormal.gItorator()).i && AN8_Model.Normdata_.HasPrev()){
AN8_Model.Normdata_.gPrev(); ++L;}
 

omesf.write(reinterpret_cast<char*>(&AN8_Model.Normdata_.ShowData(AN8_Model.Normdata_.gItorator())), 4*4);
omesf.write(reinterpret_cast<char*>(&AN8_Model.TexelCoords_.ShowData(AN8_Model.TexelCoords_.gItorator())), 2*4);

if(AN8_Model.Vertdata_.HasPrev())
for(int x = 0;x<10;++x) omesf.write(reinterpret_cast<char*>(&dummy), 4);
else
{ 
for(int x = 0;x<8;++x) omesf.write(reinterpret_cast<char*>(&dummy), 4);
dummy = 11;
omesf.write(reinterpret_cast<char*>(&dummy), 4);
omesf.write(reinterpret_cast<char*>(&dummy), 4);
}

++Le;
}while(AN8_Model.Vertdata_.HasPrev());

printf("\nData count written: %i",Le);

Le = 0;
short dummyi = 0;

printf("\nWriting Face data");

//face index

AN8_Model.Facedata_.iEnd();
do
{



omesf.write(reinterpret_cast<char*>(&dummyi), 2);
omesf.write(reinterpret_cast<char*>(&AN8_Model.Facedata_.ShowData(AN8_Model.Facedata_.gItorator()).i), 2);
if(AN8_Model.Facedata_.HasPrev())AN8_Model.Facedata_.gPrev();else break;
omesf.write(reinterpret_cast<char*>(&AN8_Model.Facedata_.ShowData(AN8_Model.Facedata_.gItorator()).i), 2);
if(AN8_Model.Facedata_.HasPrev())AN8_Model.Facedata_.gPrev();else break;
omesf.write(reinterpret_cast<char*>(&AN8_Model.Facedata_.ShowData(AN8_Model.Facedata_.gItorator()).i), 2);
if(AN8_Model.Facedata_.HasPrev())AN8_Model.Facedata_.gPrev();else break;
++Le;
}while(AN8_Model.Facedata_.HasPrev());



omesf.close();

printf("\nWritten index count %i", Le);
printf("\nDone writing .mes ! file closed.");

return 0;
}




int main(int argv, char * argc[])
{

if(argv == 2){
char buffn[255];
strcpy(buffn, argc[1]);
ParseAN8(buffn);
cout<<"\nfile converted!";
cout<<endl;

system("pause");
return 0;
}
else{
printf("skm file input parameter needed\ninput: <exe> <filname.skm>\nOutput:<filename.skm.an8>\n");
system("pause");
return 1;}

}

