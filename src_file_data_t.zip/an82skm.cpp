#include "skm.cpp"


typedef char PAD12[12];


typedef char BoneDef[100];
typedef char MatDef[128];
typedef unsigned long BitOS;



typedef struct SKMDATA_ALL
{
	SKMHeader_T Head[4];
	PAD12 pad;
	BoneDef  bones;
	MatDef  Mater;
	XYZ_ * VERT;
	XYZ_ * Normal;
	Texture_ * Texel;
	XYZi_ * index;
}SKMDATA_ALL;

ConvertVTX2SKM(char * fname)
{
PAD12 ZeroP = {0,0,0,0,0,0,0,0,0,0,0x0FF,0x0FF};

fstream file8;
SKMData skmobj;
SKMDATA_ALL ALLDATA;

file8.open(fname, ios::in | ios::out | ios::ate );
file8.seekg(0,ios::beg);
char parse_[255];
while(strcmp(parse_,".Vertex") != 0) file8>>parse_;
XYZ_ tempxyz_[3];
Texture_ TempTexel;

int pos_ = 0;
skmobj.HData[0].count = 1;
skmobj.HData[1].count = 1;
skmobj.HData[2].count = 0;
skmobj.HData[3].count = 0;

while(parse_[0] != '/'){   if(pos_ != 0) file8.seekg(pos_); skmobj.HData[2].count++;
file8>>tempxyz_[0].x>>tempxyz_[0].y>>tempxyz_[0].z; tempxyz_[0].w = 0;
file8>>tempxyz_[1].x>>tempxyz_[1].y>>tempxyz_[1].z; tempxyz_[1].w = 0;
file8>>TempTexel.x>>TempTexel.y; 
pos_ = file8.tellg();
file8>>parse_[0];
skmobj.Vertdata_.enQueue(tempxyz_[0]);
skmobj.Normdata_.enQueue(tempxyz_[1]);
skmobj.TexelCoords_.enQueue(TempTexel);
}


skmobj.Vertdata_.iEnd();
while(skmobj.Vertdata_.HasPrev() ){

tempxyz_[0] = skmobj.Vertdata_.ShowData(skmobj.Vertdata_.gItorator());
printf("\n%f %f %f",tempxyz_[0].x,tempxyz_[0].y,tempxyz_[0].z);
skmobj.Vertdata_.gPrev();
};

tempxyz_[0] = skmobj.Vertdata_.ShowData(skmobj.Vertdata_.gItorator());
printf("\n%f %f %f",tempxyz_[0].x,tempxyz_[0].y,tempxyz_[0].z);

printf("count:%d",skmobj.HData[2].count);
system("pause");




while(strcmp(parse_,".Index") != 0) file8>>parse_;



//face index entry
XYZi_ tempi_[4];
pos_ = 0; skmobj.HData[3].count = 0;
while(strcmp(parse_, "//") != 0){ if(pos_ != 0) file8.seekg(pos_);
file8>>tempi_[0].i>>tempi_[1].i>>tempi_[2].i>>tempi_[3].i; 
cout<<tempi_[0].i<<" "<<tempi_[1].i<<" "<<tempi_[2].i<<endl;
pos_ = file8.tellg();
file8>>parse_;
skmobj.HData[3].count++;
skmobj.Facedata_.enQueue(tempi_[0]);skmobj.Facedata_.enQueue(tempi_[1]);skmobj.Facedata_.enQueue(tempi_[2]);
}
file8.close();
printf("\nCount:%d",skmobj.HData[3].count);
printf("\nModel data Initialize Done!");
printf("\ninit Header");


skmobj.HData[0].count = 1;
skmobj.HData[1].count = 1;


skmobj.HData[0].offset = 40;
skmobj.HData[1].offset = 40 +(100*skmobj.HData[0].count);
skmobj.HData[2].offset = skmobj.HData[1].offset +(128* skmobj.HData[1].count);
skmobj.HData[3].offset = 80 * skmobj.HData[2].count + skmobj.HData[2].offset;


ALLDATA.Head[0] = skmobj.HData[0];
ALLDATA.Head[1] = skmobj.HData[1];
ALLDATA.Head[2] = skmobj.HData[2];
ALLDATA.Head[3] = skmobj.HData[3];

 

strcpy(ALLDATA.pad,ZeroP);


strcpy(ALLDATA.bones, "Convert_1 ");
strcpy(ALLDATA.Mater, "Temp_material ");
printf("\ndone!");
ALLDATA.VERT = new XYZ_ [skmobj.HData[2].count];
ALLDATA.Normal = new XYZ_ [skmobj.HData[2].count];
ALLDATA.Texel = new Texture_ [skmobj.HData[2].count];
ALLDATA.index = new XYZi_ [skmobj.HData[3].count];
printf("\ndone!");




skmobj.Vertdata_.iEnd(); 
skmobj.Normdata_.iEnd(); 
skmobj.TexelCoords_.iEnd(); 
 float dummyf  = 0;
int counts = 0;
XYZ_ zero_ = {0,0,0,0};
Texture_ tzero_ = {0,0,0,0};

while(skmobj.Vertdata_.HasPrev())
{
if(counts % 2 == 1){
ALLDATA.VERT[counts] = skmobj.Vertdata_.ShowData(skmobj.Vertdata_.gItorator());
ALLDATA.Normal[counts] = skmobj.Normdata_.ShowData(skmobj.Normdata_.gItorator());
ALLDATA.Texel[counts] = skmobj.TexelCoords_.ShowData(skmobj.TexelCoords_.gItorator());
}
else{

ALLDATA.VERT[counts] = zero_ ;
ALLDATA.Normal[counts] = zero_;
ALLDATA.Texel[counts] = tzero_;
}
++counts;
skmobj.Vertdata_.gPrev();skmobj.Normdata_.gPrev();skmobj.TexelCoords_.gPrev();
};
printf("\ndone!");
counts = 0;
skmobj.Facedata_.iEnd(); 
while(skmobj.Facedata_.HasPrev())
{
ALLDATA.index[counts] =  skmobj.Facedata_.ShowData(skmobj.Facedata_.gItorator());
skmobj.Facedata_.gPrev(); ++counts;
};

printf("\ndone!");
printf("\nInit file stream");

fflush(ios::out);

//fstream ofile;
//string Sname;
//Sname.assign(fname);
//Sname.append("X.skm");
//ofile.open((char*)Sname.data(), ios::in | ios::out | ios::ate | ios::trunc | ios::binary);
//ofile.seekp(0);

printf("\ndone!");
printf("\nWriting");
//ofile.write(reinterpret_cast<char*>(&ALLDATA), sizeof(ALLDATA));


printf("\nexit!");

//ofile.close();



delete   ALLDATA.Normal;
delete   ALLDATA.Texel;
delete   ALLDATA.VERT;
delete   ALLDATA.index;

return 0;



//head
//44 bits counts, offsets
//bones defs per # 100 byte block (name 48 bytes + 52 bytes unknown data per bone def)
//128 byte block material mesh mdf name null terminated followed by  0x0CCh per material possible garbage
//points data blocks
//triangles data blocks

}



int main(int argv, char* argc[])
{

if(argv==2){
ConvertVTX2SKM(argc[1]);
cout<<"\nFile conversion complete!"<<endl;
system("pause");
return 0;
}
else{

cout<<"\nAN8 input file parameter missing\n <exe> <file_name_path>"<<endl;
system("pause");
return 1;
}

}
