
#define MAIN__1.0
#include "..\skm.cpp"

#include <string.h>



typedef char PAD12[12];

typedef char BoneDef[100];
typedef char MatDef[128];
typedef unsigned long BitOS;

ConvertVTX2MES(char * fname)
{
PAD12 ZeroP = {0,0,0,0,0,0,0,0,0,0,0x0FF,0x0FF};


fstream ModelFile;

ModelFile.open(fname, ios::in | ios::out | ios::ate);
ModelFile.seekg(0);
if(ModelFile.fail()) return 1;

cout<<endl<<"file open entry point";

int Pos = -1;
char tmp[256];
string Temp;

while(Pos < 0 && !(ModelFile.fail()) )
{

ModelFile>>tmp;
Temp.assign(tmp);
Pos = Temp.find(".Faceset");


}

cout<<endl<<"parsed"<< Temp.data();

ModelFile>>GData.HData[2].count;
if(GData.HData[2].count !=1 ) return 2;

cout<<endl<<"parsed count";

Pos = -1;
while(Pos < 0 && !(ModelFile.fail()) )
{

ModelFile.getline(tmp, 80, '\n');
Temp.assign(tmp);
Pos = Temp.find(".Vertex");


}


cout<<endl<<"parsed "<<Temp.data();

strcpy(tmp, "\0\0\0\0\0");
char c1 = '\0' ;XYZ_ tmpxyz[3] = {{0}};Texture_ tmptexel;

cout<<endl<<"Entering asiignment loop\n";
system("pause");

Pos = 0;
while(c1 != '/' && !ModelFile.fail()){



ModelFile>>tmpxyz[0].x>>tmpxyz[0].y>>tmpxyz[0].z
>>tmpxyz[1].x>>tmpxyz[1].y>>tmpxyz[1].z
>>tmptexel.x>>tmptexel.y;

printf("\n%f %f %f", tmpxyz[0].x,tmpxyz[0].y,tmpxyz[0].z);
GData.Vertdata_.enQueue(tmpxyz[0]);
GData.Normdata_.enQueue(tmpxyz[1]);
GData.TexelCoords_.enQueue(tmptexel);

Pos = ModelFile.tellg();
ModelFile>>c1;
if(c1 == '/') break;
ModelFile.seekg(Pos,ios::beg);

}//while


cout<<endl<<"done.";



Pos = -1;

while(strcmp(tmp, ".Index") != 0 && !ModelFile.fail())
{

ModelFile>>tmp;
//cout<<tmp;
Temp.assign(tmp);
}




cout<<endl<<"Parse:"<<Temp.data();
c1 = 0;

XYZi_ tempi[3];
cout<<endl<<"entering Face assignment loop";
system("pause");


int tmpint;

c1 = '\0';

while(c1 != '/'){


ModelFile>>tempi[0].i>>tempi[1].i>>tempi[2].i>>tmpint;



printf("\n%d %d %d %d", tempi[0].i,tempi[1].i,tempi[2].i,tmpint);


GData.Facedata_.enQueue(tempi[0]);
GData.Facedata_.enQueue(tempi[1]);
GData.Facedata_.enQueue(tempi[2]);

Pos = ModelFile.tellg();
ModelFile>>c1;
if(c1 == '/') break;
ModelFile.seekg(-1,ios::cur);

}//while

cout<<endl<<"process complete";
ModelFile.close();


SKMHeader_T HData[4] = {{0,0}};
BoneDef BoneName;
MatDef MatName;

strcpy(BoneName, "Convert_1");
strcpy(MatName, "Temp_material");

//Init data heading //bones, materials, points, faces


//cout<<"\nPoints:"<<HData[2].count;
//cout<<"\nFaces:"<<HData[3].count;



fstream ofile;
string Sname;
Sname.assign(fname);
Sname.append(".mes");
ofile.open((char*)Sname.data(), ios::in | ios::out | ios::ate | ios::trunc | ios::binary);

//write heading

ofile.write(reinterpret_cast<char*>(&HData), 16*2);





int Le = 0;


float dummy = 0;
//ofile.seekp(HData[2].offset);


GData.Vertdata_.iEnd();
GData.Normdata_.iEnd();
GData.TexelCoords_.iEnd();


cout<<"\nwriting mes file"<<endl;
//vert norm tex data
do{


if(Le != 0){
GData.Vertdata_.gPrev();
GData.Normdata_.gPrev();
GData.TexelCoords_.gPrev();}

ofile.write(reinterpret_cast<char*>(&GData.Vertdata_.ShowData(GData.Vertdata_.gItorator())), 4*4);
ofile.write(reinterpret_cast<char*>(&GData.Normdata_.ShowData(GData.Normdata_.gItorator())), 4*4);
ofile.write(reinterpret_cast<char*>(&GData.TexelCoords_.ShowData(GData.TexelCoords_.gItorator())), 2*4);

if(GData.Vertdata_.HasPrev())
for(int x = 0;x<10;++x) ofile.write(reinterpret_cast<char*>(&dummy), 4);
else
{ 
for(int x = 0;x<8;++x) ofile.write(reinterpret_cast<char*>(&dummy), 4);
dummy = 11;
ofile.write(reinterpret_cast<char*>(&dummy), 4);
ofile.write(reinterpret_cast<char*>(&dummy), 4);
}

++Le;
}while(GData.Vertdata_.HasPrev());


cout<<"\nVert count:"<<Le<<endl;

short dummyi = 0;


Le = 0;


//face index
GData.Facedata_.iEnd();
do
{



ofile.write(reinterpret_cast<char*>(&dummyi), 2);
ofile.write(reinterpret_cast<char*>(&GData.Facedata_.ShowData(GData.Facedata_.gItorator()).i), 2);
if(GData.Facedata_.HasPrev())GData.Facedata_.gPrev();else break;
ofile.write(reinterpret_cast<char*>(&GData.Facedata_.ShowData(GData.Facedata_.gItorator()).i), 2);
if(GData.Facedata_.HasPrev())GData.Facedata_.gPrev();else break;
ofile.write(reinterpret_cast<char*>(&GData.Facedata_.ShowData(GData.Facedata_.gItorator()).i), 2);
if(GData.Facedata_.HasPrev())GData.Facedata_.gPrev();else break;
++Le;
}while(GData.Facedata_.HasPrev());

cout<<"\nFace count:"<<Le<<endl;
ofile.close();

//head
//44 bits counts, offsets
//bones defs per # 100 byte block (name 48 bytes + 52 bytes unknown data per bone def)
//128 byte block material mesh mdf name null terminated followed by  0x0CCh per material possible garbage
//points data blocks
//triangles data blocks

}



int main(int argv, char* argc[])
{

if(argv==2){
ConvertVTX2MES(argc[1]);
cout<<"\nFile conversion complete!"<<endl;
system("pause");
return 0;
}
else{

cout<<"\nAN8 input file parameter missing\n <exe> <file_name_path>"<<endl;
system("pause");
return 1;
}

}
