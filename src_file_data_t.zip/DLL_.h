//mjo WROTE THIS MACRO DEF
//2015'


#ifndef __DLL_
#define __DLL_
/*********************************************/
////////This will name the definition as a DLL export ///
////////precedes functions or data definitions or prototypes
///examples:
//Export_ int ThisFunction();
//Export_ char* ThatFunc(int, char)
//Export_ char* List_of_Names;

/////keyword is microsoft standard specifically             
////borland Compiler linker option -tWD for output *.dll
/*********************************************/


#define	Export_	__declspec(dllexport) 	
#define	Import_	__declspec(dllimport) 	

///DLL import example via Loadlibrary and Proc Address look up
//example of int return type function pointer
/***************************************************************************/
/// typedef int  (WINAPI *ThisFunctionTypePointer )(char* thisFunctions_parameter);
/// ThisFunctionTypePointer 	ThisFunctionsRealName;
//  ThisFunctionsRealName = (ThisFunctionTypePointer)  GetProcAddress( tHModule , "Dll_Def_Name");
///////////////////////////////////////////////////////////
///call example
// int rtn = ThisFunctionsRealName("Input string For Parameter1");




HMODULE * hLoadDLL(char* PathS)
{
HMODULE   tHModule;
tHModule  = LoadLibrary(PathS);
return & tHModule;
}


#endif
