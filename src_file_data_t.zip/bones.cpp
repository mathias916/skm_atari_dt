
#include <stdlib.h>
#include <stdio.h>
#include <fstream.h>
#include <iostream.h>


typedef struct BoneType_
{
short Bone_head[4];
float Bones_w [8];
}BoneType_;


namespace Boner_
{


typedef BoneType_ DataT_;
typedef int DataT_Key;
#include <list_.h>

};



int main(int argi, char* argc[])
{


Boner_::List_ Bones;

fstream bonef;

if(argi == 2)
{
bonef.open(argc[1], ios::in | ios::out | ios::ate | ios::binary);
bonef.seekg(0,ios::beg);
int count = 0;
BoneType_ tempBoneLink;
while(!bonef.fail())
{
bonef.read(reinterpret_cast<char*>(&tempBoneLink.Bone_head), 8);
bonef.read(reinterpret_cast<char*>(&tempBoneLink.Bones_w ),32);
if(bonef.fail() || bonef.eof() ) break;
Bones.enQueue(tempBoneLink);
++count;
};

bonef.close();
bonef.open("temp.obj",ios::in | ios::out | ios::trunc);



bonef<<"\# Created with Anim8or 0.95\n";
bonef<<"\# Object \"object01\":\n";
bonef<<"\# ComRec:\n"<<"g mesh01\n";
bonef<<"\# No. points ";
bonef<<count<<":"<<endl;


Bones.iEnd();
do
{

for(int x=0;x<3;++x){
if(x==0)bonef<<"v ";
bonef<<Bones.ShowData(Bones.gItorator()).Bones_w[x]<<" ";
}
bonef<<endl;

for(int x=4;x<7;++x){
if(x==4)bonef<<"v ";
bonef<<Bones.ShowData(Bones.gItorator()).Bones_w[x]<<" ";
}
bonef<<endl;

Bones.gPrev();

}while(Bones.HasPrev());

bonef.close();



system("pause");

return 0;

}






}