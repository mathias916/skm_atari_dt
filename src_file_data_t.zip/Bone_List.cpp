
#ifndef PI
#define PI 3.14159265358
#endif

#define RADDEG 180 / PI 
#define DEGRAD PI / 180


//R4 to R3
void AXIS(BONEDATA_ * OUT_d);


Bone_List::Bone_List(){ Levelmax =0;IDmax=0; Bone_Harchy=NULL;Itorator=NULL; };
Bone_List::~Bone_List(){  if(IDmax > 0) CleanList(); }




void Bone_List::DrawBonesLines()
{

#ifdef __GL_H__

//get root base address //
Address_Link * p_address = &address_i;
	Itorator = (BONE_Lnode *) p_address->Address;

float r=0,g=1,b=1;

while(Itorator !=NULL)
{



glBegin(GL_LINES);
glColor3f(r ,g,b);
glVertex3fv(Itorator->Bdata.Pos[0]);
glVertex3fv(Itorator->Bdata.Pos[1]);
glEnd();

glBegin(GL_POINTS);
glVertex3fv(Itorator->Bdata.Pos[0]);
glVertex3fv(Itorator->Bdata.Pos[1]);
glEnd();


if(b>0)
b-=.4;
else
r+=.4;

if(p_address->Next  != NULL)
{
p_address = p_address->Next;
Itorator = (BONE_Lnode *) p_address->Address;
} else break;



}

#endif

return;

}


Bone_List::InitBones()
{

//traversing list tree hiearchy using void * address assignment
// tree hiearchy goes up down left right, this is the easiest fastest way


Address_Link * p_address = &address_i;

		Itorator = (BONE_Lnode *) p_address->Address;


//root pos is of unit zero, rotating around zero

///root////pos A ///
Itorator->Bdata.Pos[0][0] = 0; //x
Itorator->Bdata.Pos[0][1] = -1; //y
Itorator->Bdata.Pos[0][2] = 0; //z

///pos B/////
Itorator->Bdata.Pos[1][0] = 0;
Itorator->Bdata.Pos[1][1] = 0;
Itorator->Bdata.Pos[1][2] = 0;

//////////////////////////////////////


AXIS(&Itorator->Bdata);


if(p_address->Next != NULL) {
p_address = p_address->Next;
Itorator = (BONE_Lnode *) p_address->Address; }else return 1;

printf("\nx:%f y:%f z:%f", Itorator->Bdata.Pos[1][0],Itorator->Bdata.Pos[1][1],Itorator->Bdata.Pos[1][2]);
getch();


////////////////////////////MACRO SIMPLY
#define 	CHECK_PARENT_SIN(X__)	(  sin( Itorator->Parent->Bdata.Axis[X__] ) )
#define 	CHECK_PARENT_COS(X__)	(  cos( Itorator->Parent->Bdata.Axis[X__] ) )
  
#define		CHECK_SIN(x__)	( sin( Itorator->Bdata.Axis[x__] )  )
#define		CHECK_COS(x__)	( Itorator->Bdata.Axis[x__] != 0 ? cos( Itorator->Bdata.Axis[x__] ) : 0  )
#define		CHECK_TAN(x__)  ( tan( Itorator->Bdata.Axis[x__] )    )

#define 	A_Ptherum(C,B) ( C>B ? (float) sqrt(( pow(C,2) - pow(B,2) )) : (float) sqrt(( pow(B,2) - pow(C,2) )) )
#define		QW	Itorator->Bdata.Axis[0]

#define	       XL_YL_(x1,x2,y1,y2)	( (x1-x2) - (y1-y2))

#define 	Txy	 XL_YL_(Itorator->Bdata.Pos[0][0],Itorator->Bdata.Pos[1][0],Itorator->Bdata.Pos[0][1],Itorator->Bdata.Pos[1][1] )  

 

while( Itorator != NULL && p_address != NULL)
{

/////assign and inheret axis rotation
AXIS(&Itorator->Bdata);

Itorator->Bdata.Axis[0] += Itorator->Parent->Bdata.Axis[0];
Itorator->Bdata.Axis[1] += Itorator->Parent->Bdata.Axis[1];
Itorator->Bdata.Axis[2] += Itorator->Parent->Bdata.Axis[2];



 
///root////pos A ///
Itorator->Bdata.Pos[0][0] = Itorator->Parent->Bdata.Pos[1][0]; //x
Itorator->Bdata.Pos[0][1] = Itorator->Parent->Bdata.Pos[1][1]; //y
Itorator->Bdata.Pos[0][2] = Itorator->Parent->Bdata.Pos[1][2]; //z
 


 	float angleRad;
	 

//sin A = a/c 
// asin(A) * c = a


/////////////////function//////////////
//float /*[3]*/ * AXIS(float Q[4])



 

printf("\nname:%s \nDeg:%f Ex%f Ey%f Ez%f",Itorator->Bdata.Name,  Itorator->Bdata.Axis[0]   ,
Itorator->Bdata.Axis[1]  , Itorator->Bdata.Axis[2]    , Itorator->Bdata.Axis[3]    );


// printf("\nSINANGLE: \< RAD%f:DEG:%f SIN:%f COS:%f TAN:%f",
//Itorator->Bdata.Axis[0], Itorator->Bdata.Axis[0]*RADDEG, sin(Itorator->Bdata.Axis[0]), cos(Itorator->Bdata.Axis[0] ), tan(Itorator->Bdata.Axis[0] ) );


///pos B/////
Itorator->Bdata.Pos[1][0] = 0;
Itorator->Bdata.Pos[1][1] = Itorator->Bdata.Pos[0][1] + Itorator->Bdata.Length ;//* /*angle*/  eular[1];
Itorator->Bdata.Pos[1][2] = 0;


//rotate axis about parental B

static float * count;
if(count==NULL){count=new float; *count=0;}

// c = \/~ a^2 + b^2    || a^2 = c^2 - B^2


if((Itorator->Bdata.Axis[0] != 0 || Itorator->Bdata.Axis[1] != 0 || Itorator->Bdata.Axis[2] != 0 ) && Itorator->Parent != NULL )
{

Itorator->Bdata.Pos[1][1] = Itorator->Bdata.Pos[0][1] +  sin(QW* Itorator->Bdata.Axis[2]) * Itorator->Bdata.Length;
Itorator->Bdata.Pos[1][0] = Itorator->Bdata.Pos[0][0] +  sin(QW* Itorator->Bdata.Axis[1]) * Itorator->Bdata.Length;
Itorator->Bdata.Pos[1][2] = Itorator->Bdata.Pos[0][2] +  sin(QW* Itorator->Bdata.Axis[3]) * Itorator->Bdata.Length;
}
/////////////////////////////////
 

//printf("\nXY_test:%f", XL_YL_(Itorator->Bdata.Pos[0][0],Itorator->Bdata.Pos[1][0],Itorator->Bdata.Pos[0][1],Itorator->Bdata.Pos[1][1] )  );

//(*count+=.01);


printf("\nRx:%f Ry:%f Rz:%f", Itorator->Bdata.Pos[1][0], Itorator->Bdata.Pos[1][1] , Itorator->Bdata.Pos[1][2] );
getch();

if(p_address->Next  != NULL)
{
p_address = p_address->Next;
Itorator = (BONE_Lnode *) p_address->Address;
} else break;

 

} 



return 0;

}


////Creates Root + Root->Child + Root->Child->Next
////Creates Itorator->next


short Bone_List::AddBone(BONEDATA_T *dIN )
{  //links current itorator next and Sets DATA

//creates root
if(Bone_Harchy == NULL){ Bone_Harchy= new BONE_Lnode; 
Bone_Harchy->Parent = NULL; //IS ROOT NO PARENT
Bone_Harchy->Next = NULL; 
Bone_Harchy->Prev = NULL; 
Bone_Harchy->Child = NULL;
Bone_Harchy->level = 0;
Bone_Harchy->branches_ = 0;
Bone_Harchy->Bdata = *dIN; 
Bone_Harchy->ID = IDmax; ++IDmax;
Itorator = Bone_Harchy; 


address_i.Address = Bone_Harchy;
address_i.ID 	  =Bone_Harchy->ID;
address_i.Next 	  = NULL;

pAddress= &address_i;



return 0;
}
else
{

///Root Makes Single Child ///
if(Itorator != NULL && Itorator == GetRoot() ){
Itorator->Child = new BONE_Lnode;
Itorator->Child->Parent = Itorator;
Itorator->Child->Child = NULL;
Itorator->Child->Next  = NULL;
Itorator->Child->Prev  = NULL;
Itorator->Child->level = Itorator->level +1; 
Itorator->Child->branches_ = 0; ++Itorator->branches_;
if(Levelmax < Itorator->Child->level) Levelmax = Itorator->Child->level;
Itorator->Child->Bdata = *dIN;
Itorator->Child->ID = IDmax; ++IDmax; 
Itorator = Itorator->Child;

pAddress->Next = new Address_Link;
pAddress->Next->Address = Itorator;
pAddress->Next->ID = Itorator->ID;
pAddress = pAddress->Next;
pAddress->Next = NULL;

return 0;
}

///Default case Add sibling/////
if(Itorator != NULL && Itorator != GetRoot() && Itorator->Parent != NULL )
{

while(Itorator->Next != NULL)  Itorator = Itorator->Next;

Itorator->Next = new BONE_Lnode;
Itorator->Next->Parent = Itorator->Parent;
Itorator->Next->Child =	NULL;
Itorator->Next->Next  = NULL;
Itorator->Next->Prev  = Itorator;
Itorator->Next->level = Itorator->level; ++Itorator->Parent->branches_;
if(Levelmax < Itorator->level) Levelmax = Itorator->level;
Itorator->Next->Bdata = *dIN;
Itorator->Next->ID = IDmax; ++IDmax; 
Itorator = Itorator->Next;


pAddress->Next = new Address_Link;
pAddress->Next->Address = Itorator;
pAddress->Next->ID = Itorator->ID;
pAddress = pAddress->Next;
pAddress->Next = NULL;

return 0;
}

} 

return 1;
}

short Bone_List::NewBone(BONEDATA_T *DataIN)
{

///First Child Only , Siblings are created by addbone

 
if(Itorator != NULL && Itorator != GetRoot() && Itorator->Child  == NULL)
{

Itorator->Child = new BONE_Lnode;
Itorator->Child->Parent = Itorator;
Itorator->Child->Next  = NULL;
Itorator->Child->Prev  = NULL;
Itorator->Child->level = Itorator->level+1; 
if(Levelmax < Itorator->Child->level) Levelmax = Itorator->Child->level;
Itorator->Child->Bdata = *DataIN;
Itorator->Child->ID = IDmax; ++IDmax; 
Itorator = Itorator->Child;

pAddress->Next = new Address_Link;
pAddress->Next->Address = Itorator;
pAddress->Next->ID = Itorator->ID;
pAddress = pAddress->Next;
pAddress->Next = NULL;


return 0;
}
else
return AddBone(DataIN);


}



BONE_Lnode * Bone_List::SearchKey(char*KEY)
{
Address_Link * Search = &address_i;
BONE_Lnode * Itora;

while(Search->Next != NULL){
Itora = (BONE_Lnode *) Search->Address;
if( strcmp( Itora->Bdata.Name ,KEY) == 0 ) return Itora;
Search = Search->Next;
}

return NULL;
}


#define OUT	OUT__i

BoneT::uLong 	Bone_List::GetCount(){return IDmax;};

short Bone_List::LinkBone(BONE_Lnode *OUT){Itorator = OUT; return 0;}//links any bone address could be another ROOT or Harchy
short Bone_List::SetData(BONEDATA_T *OUT){return 1;};  //Set Current Itorator data

short Bone_List::HasChild(){if(Itorator->Child != NULL) return 1; else return 0;}
short Bone_List::HasParent(){if(Itorator->Parent != NULL) return 1; else return 0;}
short Bone_List::HasNext(){ if(Itorator->Next != NULL) return 1; else return 0; }
short Bone_List::HasPrev(){ if(Itorator->Prev != NULL) return 1; else return 0; }

BONE_Lnode * Bone_List::GetRoot(){ return Bone_Harchy;    }  //returns  Bone_Harchy (root)
BONE_Lnode * Bone_List::GetNext(){ return Itorator = Itorator->Next; } 
BONE_Lnode * Bone_List::GetPrev(){ return Itorator = Itorator->Prev; }
BONE_Lnode * Bone_List::GetParent(){ return Itorator->Parent; }  //returns current Itorator Parent;
BONE_Lnode * Bone_List::GetLastID(){return NULL; }  //returns Most signifigant Bone ID Itorator (equal to SearchID(IDmax) )
BONE_Lnode * Bone_List::GetLastLevel(){return NULL; } //equal to  SearchLevel(Levelmax)


BONE_Lnode * Bone_List::SearchID(BoneT::uLong uLIn){return NULL; } 	//searches complete list for ID returns NULL if not found
					//if found returns Itorator

BONE_Lnode * Bone_List::SearchLevel(BoneT::uLong uLIn){return NULL; }  //same as above but for levels of branching   


BoneT::uLong 	Bone_List::GetLevel(){ return  Itorator->level; }		//returns current itorator Level data
BoneT::uLong 	Bone_List::GetBranches(){ return Itorator->branches_; }		//returns current itorator Branches count

BONE_Lnode * 	Bone_List::GetItorator(){return Itorator;}



#undef OUT

 
void 		Bone_List::CleanList()
{
 

Address_Link * p_address = &address_i;


 

 


while( p_address  != NULL )
{


	Itorator = (BONE_Lnode*) p_address->Address;

	printf("\nName:%s Level:%d id:%d  ",Itorator->Bdata.Name, Itorator->level,Itorator->ID);

	delete	Itorator; Itorator =NULL;
	p_address = p_address->Next;

--IDmax;


}

 

 Levelmax =0;IDmax=0; Bone_Harchy=NULL; 
 
 


p_address = &address_i;
Address_Link * D_address;

while(p_address != NULL){ D_address =  p_address; p_address = p_address->Next; delete D_address; }

address_i.Next= NULL;



getch();

return;

}		//frees all list contents and memmory deleting them




////Quatrenion to AXIS ROTATION
/////////////////function//////////////
void AXIS(BONEDATA_ * OUT_d)
{



//RAD ANGLES of Q

float Q[4];

Q[0] = OUT_d->Rotation[0];
Q[1] = OUT_d->Rotation[1];
Q[2] = OUT_d->Rotation[2];
Q[3] = OUT_d->Rotation[3];



/*
////////////////////////////

angle = 2 * acos(qw)
x = qx / sqrt(1-qw*qw)
y = qy / sqrt(1-qw*qw)
z = qz / sqrt(1-qw*qw)

axis angle Rotate(angle,x,y,z) Like opengl


///////////////////////////////////////////
*/

/*
/////////////////////////////////////////////////

heading = atan2(2*qy*qw-2*qx*qz , 1 - 2*qy2 - 2*qz2)
attitude = asin(2*qx*qy + 2*qz*qw)
bank = atan2(2*qx*qw-2*qy*qz , 1 - 2*qx2 - 2*qz2)

eular angle


heading=yaw
attitude=pitch
bank=roll

order of application left to right
Heading , attitude, bank
/////////////////////////////////////////////////
*/

OUT_d->Axis[0] =  (2 * acos(Q[0])  )  ;
OUT_d->Axis[1] =  Q[1] / sqrt(1 - pow(Q[0],2) ) ;
OUT_d->Axis[2] =  Q[2] / sqrt(1 - pow(Q[0],2) ) ;
OUT_d->Axis[3] =  Q[3] / sqrt(1 - pow(Q[0],2) ) ;



// OUT_d->Axis[1] = atan2( 2*Q[2]*Q[0] - 2*Q[1]*Q[3], 1 - 2 * pow(Q[2],2) - 2* pow(Q[3],2) ); 
// OUT_d->Axis[0] = asin( 2* Q[1]*Q[2] + 2*Q[3]*Q[0]);
// OUT_d->Axis[2] = atan2( 2*Q[1]*Q[0] - 2*Q[2]*Q[3], 1 - 2 * pow(Q[1],2) - 2* pow(Q[3],2));

//OUT_d->Axis[1] = asin( 2* Q[1]*Q[3] + 2*Q[2]*Q[0]);
//OUT_d->Axis[2] = asin( 2* Q[0]*Q[3] + 2*Q[1]*Q[2]);

return ;
}


 