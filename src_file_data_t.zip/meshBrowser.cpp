
#define WIN32_LEAN_AND_MEAN
#define WIN32_EXTRA_LEAN

//#define vsscanf	vsprintf
#define MAXI	1
#define MAXMODELS	2

#pragma warning(disable : 4305)
#pragma warning(disable : 4244)
#pragma warning(disable : 4183)

#include "delay.h"

#include <windows.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include <math.h>
#include <time.h>

#include <iostream>
#include <stdlib.h>
using namespace std;

#include "\library\macrodefs.h"
#include "NewTemp.h"
#include "\library\ACP.h"
#include "3dobjclass.h"

#include "skm.cpp"

bool Catch = false;
bool exiting = false;
long windowWidth = 800;
long windowHeight = 600;
long windowBits = 24;
bool fullscreen = false;
HDC hDC;

CGfxOpenGL *g_glRender = NULL;

typedef struct Test
{
  int point, grid, solid, rotation;
  float degree[3], translation[3], TexelTran[3], scale[3], Color[4];
  int  R, G, B, A;
}Test;



Test MoonT;
float AngleIncRot;

	GLfloat MoonCoord[4] = {0,0,0,0};


namespace Meshes_mes
{
typedef string DataT_;
typedef int DataT_Key;
#include <list_.h>
};


class CGfxOpenGL::Extend
{

	//example
	
	
	

public:
//example
long timer_;
Delay Timer[2];
Obj3d Models3d[1];

Meshes_mes::List_ * mes_lst;


Extend();
~Extend();
	int Render();
    int InitModels(int );
	int RenderModels();


};

CGfxOpenGL::Extend::Extend()
{	
	fstream MESFILE;
	MESFILE.open("meshes.mes",ios::in | ios::ate);
	if(MESFILE.fail()) exit(2);
	
	
	
	timer_ = 0;
}

CGfxOpenGL::Extend::~Extend()
{


}

CGfxOpenGL::Extend::Render()
{
	PUSH()
	TRANSL(0,0,-3)
	
	//EXT->Models3d[0].RenderModel();
	POP()

return 0;
}

CGfxOpenGL::Extend::RenderModels()
{
	
	
	return 0;
}

int CGfxOpenGL::Extend::InitModels(int N)
{
	

	

return 0;
}
CGfxOpenGL::CGfxOpenGL()
{

this->EXT = new Extend;
this->Messege.assign("Windows Progam - Template - MJO -");
this->Messege.append("OpenGL App");

}

CGfxOpenGL::~CGfxOpenGL()
{
delete this->EXT;
print.Shutdown();
}

char * CGfxOpenGL::Init(char CMDLN[])
{
	glClearColor(0.0, 0.0, 0.0, 0.0);
	this->Command.assign(CMDLN);
	string temp;


print.Init("arial",1,1);
print.rtrn = 0;

MoonT.A = .99;
MoonT.R = 42;


int pos;
pos = Command.find("-f");




string  name;
fstream Modelcfg;

Modelcfg.open(".\\SKM.cfg", ios::in | ios::out | ios::ate);
Modelcfg.seekg(0, ios::beg);
char tmp[80];
Modelcfg.getline(tmp, 80, '\n');
name.assign(tmp);
name.append("\0\n");

if(Modelcfg.fail()){Modelcfg.close();  exit(-1);}

LoadRaDATA((char*)name.data());

Modelcfg.getline(tmp, 80, '\n');
temp.assign(tmp);


if(Modelcfg.fail()){Modelcfg.close();  exit(-1);}


Modelcfg.close(); 

#define debug



	// enable 2D texturing
	glEnable(GL_TEXTURE_2D);


		TexelImg = new CTargaImage [MAXI];
		TexObj = new GLuint [MAXI];
	
		TexelImg[0].Load(temp.data());
		SETUPTEXELALPHA(TexObj[0], TexelImg[0]);
	
        this->Messege.append("\nExtern Command: ");
        this->Messege.append(Command.data());
	return (char*)this->Messege.data();
}

bool CGfxOpenGL::Shutdown()
{
for(int i = 0; i < MAXI; ++i)	glDeleteTextures(1, &TexObj[i]);
	TexelImg->Release();
 	//delete EXT->pMoon;
	return true;
}

void CGfxOpenGL::SetupProjection(int width, int height)
{
	if (height == 0)					// don't want a divide by zero
	{
		height = 1;					
	}

	glViewport(0, 0, width, height);		// reset the viewport to new dimensions
	glMatrixMode(GL_PROJECTION);			// set projection matrix current matrix
	glLoadIdentity();						// reset projection matrix

	// calculate perspective
	gluPerspective(54.0f,(GLfloat)width/(GLfloat)height,1.0f,1000.0f);

	glMatrixMode(GL_MODELVIEW);				// set modelview matrix
	glLoadIdentity();						// reset modelview matrix

	m_windowWidth = width;
	m_windowHeight = height;
}

void CGfxOpenGL::Prepare()
{

	if(AngleIncRot <360)
	AngleIncRot += .5;
	else AngleIncRot = 0;


}


void CGfxOpenGL::Render()
{
	// clear screen and depth buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// load the identity matrix (clear to default position and orientation)
	

	// draw the left polygon
	// translate the world coordinate system along the z axis

	MODELVIEW
	glLoadIdentity();

	gluLookAt(
		0,0, MoonT.translation[0]  ,
		0,0,-6,
		0,1,0
		);

	
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);







	//enable blending and alpha
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);


    //Sample Light/////////////////////////////////////
    //you input for color//////////////////////////////
                                                     //
       glEnable(GL_LIGHT0);                          //
       glEnable(GL_LIGHTING);                        //
                                                     //
       glLightfv(GL_LIGHT0, GL_AMBIENT , CP[White+2] );   //
       glLightfv(GL_LIGHT0, GL_DIFFUSE , CP[White+4] );   //
       glLightfv(GL_LIGHT0, GL_SPECULAR, CP[White] );   //
       const float Lpos[]={0.0f, 40.0f,  40.0f, 0.0f}; //
       glLightfv(GL_LIGHT0,GL_POSITION, Lpos);       //
                                                   //
    ///uncomment to use////////////////////////////////

	 glEnable(GL_COLOR_MATERIAL);

    //Sample Material Def//////////////////////////////
    ///////////////////////////////////////////////////
       glMaterialfv(GL_FRONT, GL_AMBIENT , CP[42]);
       glMaterialfv(GL_FRONT, GL_DIFFUSE , CP[42 +4]);
       glMaterialfv(GL_FRONT, GL_SPECULAR, CP[42]);//
       glMaterialf(GL_FRONT, GL_SHININESS , 50.0);    //
    //////////////////////////////////////////////////
    //uncomment to use/////////////////////////////////

	MODELVIEW

	TRANSL(0,0,-5)

	//autoRotation
	if(MoonT.rotation)
	glRotatef(AngleIncRot, 0,1,0);

	if(MoonT.rotation) glRotatef(AngleIncRot, 0, 1, 0);
	glRotatef(MoonT.degree[0], 1, 0, 0);
	glRotatef(MoonT.degree[1], 0, 1, 0);
	glRotatef(MoonT.degree[2], 0, 0, 1);

	//mesh mode
	if(MoonT.point)
	glPolygonMode(GL_FRONT_AND_BACK,GL_POINT);
	else
	if(!MoonT.grid)
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	else
	if(MoonT.grid)
	glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);



	// bind the texture
	glBindTexture(GL_TEXTURE_2D, TexObj[0]);
  	glScalef(1, 1, 1);
	glMatrixMode(GL_TEXTURE);
	glColor4f(1,0,0,1);

	glMatrixMode(GL_MODELVIEW);



PUSH()
	
POP()


PUSH()
//TRANSL(0,0,-10)
//print.PrintFont(0,"Hello Craft");
POP()
glPointSize (1.5);
SCALEALL(.25)


 
glBegin(GL_TRIANGLES);


//GData.Model_.	GData.Vertdata_.	

GData.Model_.iEnd();	
GData.Normdata_.iEnd();
int c = 0;

while(GData.Model_.HasPrev() ){

++c;


glTexCoord2f( 	GData.Model_.ShowData(GData.Model_.gItorator()).Texel.x,
		GData.Model_.ShowData(GData.Model_.gItorator()).Texel.y);

glNormal3f(	GData.Model_.ShowData(GData.Model_.gItorator()).Norm.x,
		GData.Model_.ShowData(GData.Model_.gItorator()).Norm.y,
		GData.Model_.ShowData(GData.Model_.gItorator()).Norm.z);

glVertex3f(	GData.Model_.ShowData(GData.Model_.gItorator()).Vect.x,
		GData.Model_.ShowData(GData.Model_.gItorator()).Vect.y,
		GData.Model_.ShowData(GData.Model_.gItorator()).Vect.z);

if(GData.Normdata_.HasPrev()) GData.Normdata_.gPrev();

GData.Model_.gPrev();
if(!GData.Model_.HasPrev()) break;
//}



};//while

glEnd();

}



void SetupPixelFormat(HDC hDC)
{
	int pixelFormat;

	PIXELFORMATDESCRIPTOR pfd =
	{	
		sizeof(PIXELFORMATDESCRIPTOR),	// size
			1,							// version
			PFD_SUPPORT_OPENGL |		// OpenGL window
			PFD_DRAW_TO_WINDOW |		// render to window
			PFD_DOUBLEBUFFER,			// support double-buffering
			PFD_TYPE_RGBA,				// color type
			32,							// prefered color depth
			0, 0, 0, 0, 0, 0,			// color bits (ignored)
			0,							// no alpha buffer
			0,							// alpha bits (ignored)
			0,							// no accumulation buffer
			0, 0, 0, 0,					// accum bits (ignored)
			16,							// depth buffer
			0,							// no stencil buffer
			0,							// no auxiliary buffers
			PFD_MAIN_PLANE,				// main layer
			0,							// reserved
			0, 0, 0,					// no layer, visible, damage masks
	};

	pixelFormat = ChoosePixelFormat(hDC, &pfd);
	SetPixelFormat(hDC, pixelFormat, &pfd);
}

LRESULT CALLBACK MainWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static HDC hDC;
	static HGLRC hRC;
	int height, width;

	RegisterHotKey(hWnd, 1, MOD_CONTROL, VK_UP);//save data hotkey
	RegisterHotKey(hWnd, 2, MOD_CONTROL, VK_DOWN);//save data hotkey
	RegisterHotKey(hWnd, 3, MOD_CONTROL, VK_LEFT);//save data hotkey
	RegisterHotKey(hWnd, 4, MOD_CONTROL, VK_RIGHT);//save data hotkey
	RegisterHotKey(hWnd, 5, MOD_ALT, VK_UP);//save data hotkey
	RegisterHotKey(hWnd, 6, MOD_ALT, VK_DOWN);//save data hotkey
	RegisterHotKey(hWnd, 7, MOD_ALT, VK_LEFT);//save data hotkey
	RegisterHotKey(hWnd, 8, MOD_ALT, VK_RIGHT);//save data hotkey

	// dispatch messages
	switch (uMsg)
	{	
	case WM_CREATE:			// window creation
		hDC = GetDC(hWnd);
		SetupPixelFormat(hDC);
		//SetupPalette();
		hRC = wglCreateContext(hDC);
		wglMakeCurrent(hDC, hRC);
		break;

	case WM_DESTROY:			// window destroy
	case WM_QUIT:
    UnregisterHotKey(hWnd, 1);
    UnregisterHotKey(hWnd, 2);
    UnregisterHotKey(hWnd, 3);
    UnregisterHotKey(hWnd, 4);
    UnregisterHotKey(hWnd, 5);
    UnregisterHotKey(hWnd, 6);
    UnregisterHotKey(hWnd, 7);
    UnregisterHotKey(hWnd, 8);

	case WM_CLOSE:					// windows is closing

		// deselect rendering context and delete it
		wglMakeCurrent(hDC, NULL);
		wglDeleteContext(hRC);

		// send WM_QUIT to message queue
		PostQuitMessage(0);
		break;

	case WM_SIZE:
		height = HIWORD(lParam);		// retrieve width and height
		width = LOWORD(lParam);

		g_glRender->SetupProjection(width, height);
		break;

	case WM_ACTIVATEAPP:		// activate app
		break;

	case WM_PAINT:				// paint
		PAINTSTRUCT ps;
		BeginPaint(hWnd, &ps);
		EndPaint(hWnd, &ps);
		break;

	case WM_LBUTTONDOWN:		// left mouse button
		break;

	case WM_RBUTTONDOWN:		// right mouse button
		break;

	case WM_MOUSEMOVE:			// mouse movement
		break;

	case WM_LBUTTONUP:			// left button release
		break;

	case WM_RBUTTONUP:			// right button release
		break;

	case WM_KEYUP:
		break;

	case WM_HOTKEY:
	switch(wParam)
	{

	case 1:
	MoonT.TexelTran[1] += .01;
	break;

	case 2:
	MoonT.TexelTran[1] -= .01;
	break;

	case 3:
	MoonT.TexelTran[0] -= .01;
	break;

	case 4:
	MoonT.TexelTran[0] += .01;
	break;

	case 5:
	MoonT.scale[1] -=.01;
	break;

	case 6:
	MoonT.scale[1] +=.01;
	break;

	case 7:
	MoonT.scale[0] -=.01;
	break;

	case 8:
	MoonT.scale[0] +=.01;
	break;

	
	

	default:
	break;
        }
	break;

	case WM_KEYDOWN:
		int fwKeys;
		LPARAM keyData;
		fwKeys = (int)wParam;    // virtual-key code 
		keyData = lParam;          // key data 

        switch(fwKeys)
	{
	    case VK_ESCAPE:
            PostQuitMessage(0);
	    exiting = true;
            break;
	
	case 0x47:
	if(!MoonT.grid)
	MoonT.grid = 1;
	else
	if(MoonT.grid)
	MoonT.grid = 0;
	break;

	case 0x43:
	if(MoonT.R <49)
	++MoonT.R;
	else MoonT.R = 0;
	MoonT.Color[0] = Opeqs.CPA[(int)MoonT.R][0];
	MoonT.Color[1] = Opeqs.CPA[(int)MoonT.R][1];
	MoonT.Color[2] = Opeqs.CPA[(int)MoonT.R][2];
	break;

	case 0x58:
	if(MoonT.R > 0) --MoonT.R; else MoonT.R = 48;
	MoonT.Color[0] = Opeqs.CPA[(int)MoonT.R][0];
	MoonT.Color[1] = Opeqs.CPA[(int)MoonT.R][1];
	MoonT.Color[2] = Opeqs.CPA[(int)MoonT.R][2];
	break;

	case 0x56:
	if(MoonT.A < 1.0) MoonT.A  += .05; else MoonT.A = 0.1;
	MoonT.Color[3] = MoonT.A;
	break;


	case 0x50:
	if(!MoonT.point)
        MoonT.point = 1;
	else
        if(MoonT.point)
	MoonT.point = 0;
	break;

	case VK_SPACE:
	if(!MoonT.rotation)
	MoonT.rotation = 1;
	else
	if(MoonT.rotation)
	MoonT.rotation = 0;
	AngleIncRot = 0;
	break;

	case VK_LEFT:
        if(MoonT.degree[1] > -1)
	MoonT.degree[1] -= (float)1;
	else
	MoonT.degree[1] = (float)360;
	break;
	
	case VK_RIGHT:
        if(MoonT.degree[1] < 360)
	MoonT.degree[1] += (float)1;
	else
	MoonT.degree[1] = (float)0;
	break;


	case VK_DOWN:
        if(MoonT.degree[0] > -1)
	MoonT.degree[0] -= (float)1;
	else
	MoonT.degree[0] = (float)360;
	break;
	
	case VK_UP:
        if(MoonT.degree[0] < 360)
	MoonT.degree[0] += (float)1;
	else
	MoonT.degree[0] = (float)0;
	break;

	case VK_OEM_PLUS:       
	MoonT.translation[0] += (float)1;	
	break;

	case VK_OEM_MINUS:
        if(MoonT.translation[0] < 360)
	MoonT.translation[0] -= (float)1;
	break;

	case VK_RETURN:
	MoonT.translation[0] = -4;
	break;

        default:
            break;
        }
 
		

		break;

	default:
		break;
	}
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	WNDCLASSEX windowClass;		// window class
	HWND	   hwnd;			// window handle
	MSG		   msg;				// message
	DWORD	   dwExStyle;		// Window Extended Style
	DWORD	   dwStyle;			// Window Style
	RECT	   windowRect;

	g_glRender = new CGfxOpenGL;

	//g_glRender->Init(lpCmdLine);

	windowRect.left=(long)0;						// Set Left Value To 0
	windowRect.right=(long)windowWidth;	// Set Right Value To Requested Width
	windowRect.top=(long)0;							// Set Top Value To 0
	windowRect.bottom=(long)windowHeight;	// Set Bottom Value To Requested Height

	// fill out the window class structure
	windowClass.cbSize			= sizeof(WNDCLASSEX);
	windowClass.style			= CS_HREDRAW | CS_VREDRAW;
	windowClass.lpfnWndProc		= MainWindowProc;
	windowClass.cbClsExtra		= 0;
	windowClass.cbWndExtra		= 0;
	windowClass.hInstance		= hInstance;
	windowClass.hIcon			= LoadIcon(NULL, IDI_APPLICATION);	// default icon
	windowClass.hCursor			= LoadCursor(NULL, IDC_ARROW);		// default arrow
	windowClass.hbrBackground	= NULL;								// don't need background
	windowClass.lpszMenuName	= NULL;								// no menu
	windowClass.lpszClassName	= "GLClass";
	windowClass.hIconSm			= LoadIcon(NULL, IDI_WINLOGO);		// windows logo small icon

	// register the windows class
	if (!RegisterClassEx(&windowClass))
		return 0;

	if (fullscreen)								// fullscreen?
	{
		DEVMODE dmScreenSettings;					// device mode
		memset(&dmScreenSettings,0,sizeof(dmScreenSettings));
		dmScreenSettings.dmSize = sizeof(dmScreenSettings);	
		dmScreenSettings.dmPelsWidth = windowWidth;			// screen width
		dmScreenSettings.dmPelsHeight = windowHeight;			// screen height
		dmScreenSettings.dmBitsPerPel = windowBits;				// bits per pixel
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

		// 
		if (ChangeDisplaySettings(&dmScreenSettings, CDS_FULLSCREEN) != DISP_CHANGE_SUCCESSFUL)
		{
			// setting display mode failed, switch to windowed
			MessageBox(NULL, "Display mode failed", NULL, MB_OK);
			fullscreen = FALSE;	
		}
	}

	if (fullscreen)								// Are We Still In Fullscreen Mode?
	{
		dwExStyle=WS_EX_APPWINDOW;					// Window Extended Style
		dwStyle=WS_POPUP;						// Windows Style
		ShowCursor(FALSE);						// Hide Mouse Pointer
	}
	else
	{
		dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;			// Window Extended Style
		dwStyle=WS_OVERLAPPEDWINDOW;					// Windows Style
	}

	AdjustWindowRectEx(&windowRect, dwStyle, FALSE, dwExStyle);		// Adjust Window To True Requested Size


    



	// class registered, so now create our window
	hwnd = CreateWindowEx(NULL,									// extended style
		"GLClass",							// class name
		g_glRender->Messege.data(),	                                // app name
		dwStyle | WS_CLIPCHILDREN |
		WS_CLIPSIBLINGS,
		0, 0,								// x,y coordinate
		windowRect.right - windowRect.left,
		windowRect.bottom - windowRect.top, // width, height
		NULL,								// handle to parent
		NULL,								// handle to menu
		hInstance,							// application instance
		NULL);								// no extra params

						// update the window
	
        hDC = GetDC(hwnd);

	// check if window creation failed (hwnd would equal NULL)
	if (!hwnd)
		return 0;


	
       
  	ShowWindow(hwnd, SW_SHOW);			// display the window
	UpdateWindow(hwnd);

	
#ifndef debug
	g_glRender->Init(lpCmdLine);	
			
#else

MessageBox(NULL, g_glRender->Init(lpCmdLine), NULL, MB_OK);
#endif

	fullscreen = FALSE;
	if(Catch)
	exiting = true;

       
  	ShowWindow(hwnd, SW_SHOW);			// display the window
	UpdateWindow(hwnd);					// update the window


	while (!exiting)
	{
		g_glRender->Prepare();
		g_glRender->Render();
		SwapBuffers(hDC);

		while (PeekMessage (&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			if (!GetMessage (&msg, NULL, 0, 0))
			{
				exiting = true;
				break;
			}

			TranslateMessage (&msg);
			DispatchMessage (&msg);
		}
	}


	delete g_glRender;

	if (fullscreen)
	{
		ChangeDisplaySettings(NULL,0);					// If So Switch Back To The Desktop
		ShowCursor(TRUE);						// Show Mouse Pointer
	}

	return (int)msg.wParam;
}


