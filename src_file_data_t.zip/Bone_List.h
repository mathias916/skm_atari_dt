#ifndef	__BONELIST__
#define __BONELIST__

#include <sfx.h>

////////////////////////////////////////////////
//3D OBJECT CLASS
//FUNCTION: LOAD 3D MODEL OBJECT FILES AND RENDER
//USING OPEN GL..
//PROGRAMMER: MATHIAS J. ODEA
//DATE: 11 JAN 2012
//
////////////////////////////////////////////////

namespace BoneT
{

typedef float   XYZ_[3];
typedef float  WXYZ_[4];	// 4-d quatrion rotation still unknown
typedef unsigned long uLong;


}

// char Obj[64]; //name of attached object

typedef struct WEIGHT
{
unsigned long VertID;
unsigned long BoneID; 
float Strength;
}WEIGHT;

namespace Weights
{

typedef WEIGHT DataT_;
typedef BoneT::uLong DataT_Key;

#include <List_.h>
}


///Quatrion  ?    W, X,Y,Z
//Rotation formua  
////ACOS(angle) * 2


typedef struct BONEDATA_ 
{
  char	Name[80];
  BoneT::uLong	ID;
  BoneT::XYZ_  Influence[2];   //2 influence Eliptical BULB Sizes 1 inner the other outer
  BoneT::XYZ_  Origin;       //base calc angles 
  BoneT::WXYZ_ Rotation;    //rotation angles based around origin (pitch,yaw,roll or x,y,z)
  BoneT::WXYZ_ Axis;
  BoneT::XYZ_  Eular;
  BoneT::XYZ_  Pos[2];	    // Vector line that represents postion of bone Endings
  float	      Length;	    //trigonometric reference for previous influence
}BONEDATA_;


typedef BONEDATA_ BONEDATA_T;


typedef struct BONE_Lnode
{
BoneT::uLong ID;
BoneT::uLong level;
BoneT::uLong branches_;

BONEDATA_T  Bdata;
 

BONE_Lnode * Parent; // previous branching bone / previous level
BONE_Lnode * Next;
BONE_Lnode * Prev;   
BONE_Lnode * Child;
}BONE_Lnode;

/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////


typedef struct Address_Link
{
BoneT::uLong ID;
void * Address;
Address_Link *  Next;
}Address_Link ;



class Bone_List
{

private:

BoneT::uLong	Levelmax;
BoneT::uLong	IDmax;  	//not limits, but counters

BONE_Lnode *Bone_Harchy;
BONE_Lnode *Itorator;

Address_Link address_i;   	//address list for Bone List
Address_Link *pAddress;   

Address_Link Waddress_link; //for new weights lists


Weights::List_ * WEIGHTS_List;



public:

Bone_List();
~Bone_List();

/////////////List Functions//////////////////////////////


short AddBone(BONEDATA_T *); 		   //adds Root , Root->Child , Root->Child->Siblings
short NewBone(BONEDATA_T *);		   // creates first Child bones only

short LinkBone(BONE_Lnode *); //links any bone address could be another ROOT or Harchy
short SetData(BONEDATA_T *);  //Set Current Itorator data

short HasChild();
short HasParent();
short HasNext();
short HasPrev();

BONE_Lnode * GetRoot();  //returns  Bone_Harchy (root)
BONE_Lnode * GetNext(); 
BONE_Lnode * GetPrev();
BONE_Lnode * GetParent();  //returns current Itorator Parent;
BONE_Lnode * GetLastID();  //returns Most signifigant Bone ID Itorator (equal to SearchID(IDmax) )
BONE_Lnode * GetLastLevel(); //equal to  SearchLevel(Levelmax)


BONE_Lnode * SearchKey(char*);

BONE_Lnode * SearchID(BoneT::uLong);	//searches complete list for ID returns NULL if not found
					//if found returns Itorator

BONE_Lnode * SearchLevel(BoneT::uLong); //same as above but for levels of branching   

BoneT::uLong 	GetCount();		//returns total bone IDs max
BoneT::uLong 	GetLevel();		//returns current itorator Level data
BoneT::uLong 	GetBranches();		//returns current itorator Branches count

BONE_Lnode * 	GetItorator();

void 		CleanList();		//frees all list contents and memmory deleting them

/////////////////////////////////////////////////////////////
//Bone Data type Vector Calc/Functions///////////////////////

InitBones();            //intializes bone positions using Rotation,Length pos A,B
			// postion A is inherited by parent, pos B is calculated using trig

void  DrawBonesLines();


};

/////////////////////////////Class member function definitions////////////////
	 
#include <Bone_List.cpp>
/////////////////////////////////////////////////////////////////CLASS Bone_List END

#endif