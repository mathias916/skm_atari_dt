#include <sfx.h>
#include <winfx.h>

#define MainWindowProc	DefWindowProc

#include <printtext.H>


#ifndef CREATE_FLAG_TABLE_
#define  CREATE_FLAG_TABLE_
//////////////////////////////////////

///Creation Flag Table///

DWORD	CreateFlagi[] = {
DEBUG_PROCESS            ,   
DEBUG_ONLY_THIS_PROCESS   ,  
CREATE_SUSPENDED           , 
DETACHED_PROCESS            ,
CREATE_NEW_CONSOLE          ,
NORMAL_PRIORITY_CLASS       ,
IDLE_PRIORITY_CLASS         ,
HIGH_PRIORITY_CLASS         ,
REALTIME_PRIORITY_CLASS     ,
CREATE_NEW_PROCESS_GROUP    ,
CREATE_UNICODE_ENVIRONMENT  ,
CREATE_SEPARATE_WOW_VDM     ,
CREATE_SHARED_WOW_VDM       ,
CREATE_FORCEDOS             ,
BELOW_NORMAL_PRIORITY_CLASS ,
ABOVE_NORMAL_PRIORITY_CLASS ,
CREATE_BREAKAWAY_FROM_JOB   
};

////Creation flag cStrings///

char	CreateFlagL[17][64] = {
{"DEBUG_PROCESS  \0"}		,
{"DEBUG_ONLY_THIS_PROCESS  \0"}	,
{"CREATE_SUSPENDED  \0"}		,
{"DETACHED_PROCESS  \0"}           ,
{"CREATE_NEW_CONSOLE  \0"}          ,
{"NORMAL_PRIORITY_CLASS  \0"}       ,
{"IDLE_PRIORITY_CLASS  \0"}         ,
{"HIGH_PRIORITY_CLASS  \0"}         ,
{"REALTIME_PRIORITY_CLASS  \0"}     ,
{"CREATE_NEW_PROCESS_GROUP  \0"}    ,
{"CREATE_UNICODE_ENVIRONMENT  \0"}  ,
{"CREATE_SEPARATE_WOW_VDM  \0"}     ,
{"CREATE_SHARED_WOW_VDM  \0"}       ,
{"CREATE_FORCEDOS  \0"}             ,
{"BELOW_NORMAL_PRIORITY_CLASS  \0"},
{"ABOVE_NORMAL_PRIORITY_CLASS  \0"},
{"CREATE_BREAKAWAY_FROM_JOB  \0"}
};

#define TABLE_SIZE	17
/////////////////////////////////////////
#endif

#include <timer.h>
 

GdiIO *tGDI;

////////////////////////////////////////////////////////////////////////////
//
//MAIN
///////////////////////////////////////////////////
 
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{



MSG msg;

 Timer_ Tc;
 
//has command argument?
//if(nShowCmd == 0 )  return 1;



char *fname = lpCmdLine;
fname= strtok(fname, "\"");



MessageBoxA(NULL, fname,"Debug", MB_OK);


/*
typedef struct _SYSTEM_INFO {
    union {
        DWORD dwOemId;          // Obsolete field...do not use
        struct {
            WORD wProcessorArchitecture;
            WORD wReserved;
        };
    };
    DWORD dwPageSize;
    LPVOID lpMinimumApplicationAddress;
    LPVOID lpMaximumApplicationAddress;
    DWORD_PTR dwActiveProcessorMask;
    DWORD dwNumberOfProcessors;
    DWORD dwProcessorType;
    DWORD dwAllocationGranularity;
    WORD wProcessorLevel;
    WORD wProcessorRevision;
} SYSTEM_INFO, *LPSYSTEM_INFO;
*/


 

///get system info
SYSTEM_INFO MachineInfo;
GetSystemInfo( &MachineInfo );

tGDI=new GdiIO;


tGDI->tRECT.bottom = 500;
tGDI->tRECT.right  = 500;
tGDI->createWindow(hInstance, 0, 0 );



int CoreN = 1;
HWND mWNDh = GetForegroundWindow();


 
UINT c=0;
int Carret =5;
tGDI->SelectFont("Times New Roman",15);

tGDI->Cls();

//////////////////////////////////////////////////////////

do
{
msg.wParam =0;

tGDI->SetXY(0,0);
tGDI->wPuts("Select Creation Flag:"); tGDI->iLine(); 

for(int x=0;x<TABLE_SIZE;++x){
//do colors somwhere here maybe?
if(Carret == x)
tGDI->SetTextFgBg(RGB(255,255,0), 0 );
else
tGDI->SetTextFgBg(RGB(255,255,255), 0 );

tGDI->wPuts(CreateFlagL[x]); tGDI->iLine(); 
}


 GetMessage (&msg, NULL, 0, 0);
	 
 
if( msg.message == WM_KEYDOWN )
	switch( msg.wParam )
	{	
	case VK_UP:
	if(Carret>0) --Carret;
	break;

	case VK_DOWN:
	if(Carret< TABLE_SIZE-1) ++Carret;
	break;

	default:
	break;

	}


	
	//Calls window' default procedure	
	CallWindowProcA(DefWindowProc, mWNDh, msg.message, msg.wParam, 0);

if(GetDC(mWNDh) == NULL) return 0;

}while(msg.wParam !=VK_RETURN);

///////////////////////////////////////////////
//update selection here TODO
DWORD CParam = CreateFlagi[Carret];




msg.message =0;
msg.wParam=0;
GetMessage (&msg, NULL, 0, 0);


char cBUFF[64];


 tGDI->Cls();

Carret=0;

do
{
msg.wParam =0;

tGDI->SetXY(0,0); 
tGDI->wPuts("Select Processor Core affinity\0"); tGDI->iLine(); 

 
for(UINT x=0; x<MachineInfo.dwNumberOfProcessors ;++x){
//do colors somwhere here maybe?
if(Carret == x)
tGDI->SetTextFgBg(RGB(255,255,0), 0 );
else
tGDI->SetTextFgBg(RGB(255,255,255), 0 );

sprintf(cBUFF, "%d Cores Active                    \0", x+1);
tGDI->wPuts(cBUFF); tGDI->iLine(); 

}


 GetMessage (&msg, NULL, 0, 0);
	 
 
if( msg.message == WM_KEYDOWN )
	switch( msg.wParam )
	{	
	case VK_UP:
	if(Carret>0) --Carret;
	break;

	case VK_DOWN:
	if(Carret< MachineInfo.dwNumberOfProcessors -1) ++Carret;
	break;

	default:
	break;

	}


 

	//Calls window' default procedure	
	CallWindowProcA(DefWindowProc, mWNDh, msg.message, msg.wParam, 0);

if(GetDC(mWNDh) == NULL) return 0;

 
}while(msg.wParam != VK_RETURN);
 




//DWORD ParamA = , 0);

//////////////////////////////////////////////////
msg.message =0;
msg.wParam=0;
GetMessage (&msg, NULL, 0, 0);

 

/*
 typedef struct _STARTUPINFOA {
    DWORD   cb;
    LPSTR   lpReserved;
    LPSTR   lpDesktop;
    LPSTR   lpTitle;
    DWORD   dwX;
    DWORD   dwY;
    DWORD   dwXSize;
    DWORD   dwYSize;
    DWORD   dwXCountChars;
    DWORD   dwYCountChars;
    DWORD   dwFillAttribute;
    DWORD   dwFlags;
    WORD    wShowWindow;
    WORD    cbReserved2;
    LPBYTE  lpReserved2;
    HANDLE  hStdInput;
    HANDLE  hStdOutput;
    HANDLE  hStdError;
} STARTUPINFOA,
*/


STARTUPINFO STRT;
PROCESS_INFORMATION MYINFO;
SECURITY_DESCRIPTOR mySD;
SECURITY_ATTRIBUTES MYSecurity;



/*
BOOL WINAPI SetSecurityDescriptorDacl(
  mySDCL, 	// _Inout_   PSECURITY_DESCRIPTOR pSecurityDescriptor,
  FALSE,		//  _In_     BOOL bDaclPresent,
  NULL		//  _In_opt_   PACL pDacl,
  FALSE		//  _In_      BOOL bDaclDefaulted
);
*/

GetStartupInfoA( &STRT);

// 0x00002000 | 0x00001000 |

STRT.dwFlags = 0x00001000 | STARTF_USESTDHANDLES;
STRT.lpTitle =  "SS App";

///Create directory string

char parse[254];
strcpy(parse, fname );
int x;
for(x=strlen(parse);x>0 ;--x) if(parse[x] == '\\') break;
string Dir;
Dir.assign(parse, 0, x);


MessageBoxA(NULL,(char*) Dir.data(),"Debug", MB_OK);

CreateProcessA(
   fname,
    NULL,			//CMD LINE
    NULL, 			//IN LPSECURITY_ATTRIBUTES lpProcessAttributes,
    NULL,  			//IN LPSECURITY_ATTRIBUTES lpThreadAttributes,
    TRUE,
    CParam , 			//IN DWORD dwCreationFlags,
    NULL, 			//IN LPVOID lpEnvironment,
    Dir.data(),			//current dir
    &STRT, 			//IN LPSTARTUPINFOA lpStartupInfo,
    &MYINFO			//OUT LPPROCESS_INFORMATION lpProcessInformation
    );


DWORD affinity=1;
DWORD Shift=1;

for(int x=0;x<Carret;++x)
{
Shift *=2;
affinity+=Shift;
}



SetProcessAffinityMask(
    MYINFO.hProcess, 		//IN HANDLE hProcess,
    affinity			//dwProcessAffinityMask 
    );





return 0;
}




